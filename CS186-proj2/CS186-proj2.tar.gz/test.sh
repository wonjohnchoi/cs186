ant runtest -Dtest=PredicateTest &&
ant runtest -Dtest=JoinPredicateTest &&
ant runtest -Dtest=FilterTest &&
ant runtest -Dtest=JoinTest &&
ant runtest -Dtest=InsertTest &&
ant runsystest -Dtest=InsertTest &&
ant runsystest -Dtest=DeleteTest &&
ant runsystest -Dtest=EvictionTest
